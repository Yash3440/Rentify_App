# Rentify

Rentify is a web application designed to simplify the process of finding rental properties. It enables property owners to list their properties and allows potential tenants to search for properties based on their preferences.

## Features

- **User Authentication**: Register and log in as either a property owner or a tenant.
- **Property Listing**: Property owners can list their properties with details such as location, area, bedrooms, bathrooms, and nearby facilities.
- **Property Search**: Tenants can search for properties based on location, number of bedrooms, and number of bathrooms.
- **Property Interest**: Tenants can express interest in a property and view contact details of the property owner.

## Technologies Used

- **Flask**: A micro web framework for Python used for building the backend of the application.
- **HTML/CSS**: Frontend design and structure.
- **JavaScript**: Client-side scripting for interactive features.
- **SQLite**: Lightweight database for storing user and property data.
- **Heroku**: Cloud platform used for deploying the application.

## Installation

1. **Clone the Repository**
2. Install dependencies
3. Run the application

4. Access the application in your web browser at `http://localhost:3001`.

## Deployment

The application is deployed on Heroku. You can access it at: [Rentify](https://rentify.herokuapp.com/)

## Contributing

Contributions are welcome! If you find any bugs or have suggestions for improvement, please open an issue or submit a pull request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
no