const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const cors = require('cors');

app.use(bodyParser.json());
app.use(cors());

let users = [];
let properties = [];
let loggedInUser = null;

app.post('/register', (req, res) => {
    const { firstName, lastName, email, password, phoneNumber } = req.body;
    users.push({ firstName, lastName, email, password, phoneNumber });
    res.sendStatus(201);
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        loggedInUser = user;
        res.sendStatus(200);
    } else {
        res.sendStatus(401);
    }
});

app.post('/properties', (req, res) => {
    if (!loggedInUser) {
        return res.sendStatus(401);
    }
    const { location, area, bedrooms, bathrooms, nearbyFacilities } = req.body;
    properties.push({ id: properties.length + 1, location, area, bedrooms, bathrooms, nearbyFacilities, seller: loggedInUser.email });
    res.sendStatus(201);
});

app.get('/properties', (req, res) => {
    res.json(properties);
});

app.put('/properties/:id', (req, res) => {
    if (!loggedInUser) {
        return res.sendStatus(401);
    }
    const property = properties.find(p => p.id === parseInt(req.params.id));
    if (property.seller !== loggedInUser.email) {
        return res.sendStatus(403);
    }
    Object.assign(property, req.body);
    res.sendStatus(200);
});

app.delete('/properties/:id', (req, res) => {
    if (!loggedInUser) {
        return res.sendStatus(401);
    }
    const propertyIndex = properties.findIndex(p => p.id === parseInt(req.params.id));
    if (properties[propertyIndex].seller !== loggedInUser.email) {
        return res.sendStatus(403);
    }
    properties.splice(propertyIndex, 1);
    res.sendStatus(200);
});

app.post('/interest/:id', (req, res) => {
    if (!loggedInUser) {
        return res.sendStatus(401);
    }
    const property = properties.find(p => p.id === parseInt(req.params.id));
    const seller = users.find(u => u.email === property.seller);
    res.json({ email: seller.email, phoneNumber: seller.phoneNumber });
    sendEmail(seller.email, `Interest in your property`, `A user is interested in your property`);
    sendEmail(loggedInUser.email, `Property details`, `Contact details of the seller: ${seller.email}, ${seller.phoneNumber}`);
});

function sendEmail(to, subject, text) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'youremail@gmail.com',
            pass: 'yourpassword'
        }
    });
    const mailOptions = {
        from: 'youremail@gmail.com',
        to,
        subject,
        text
    };
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}

app.listen(3001, () => {  
    console.log('Server started on port 3001');
});
