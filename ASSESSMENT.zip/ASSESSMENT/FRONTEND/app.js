document.getElementById('login-form').addEventListener('submit', login);
document.getElementById('register-form').addEventListener('submit', register);
document.getElementById('apply-filters').addEventListener('click', getProperties);

function login(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    fetch('http://localhost:3001/login', {  // Updated port number
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.ok ? alert('Login successful') : alert('Login failed'));
}

function register(event) {
    event.preventDefault();
    const firstName = document.getElementById('first-name').value;
    const lastName = document.getElementById('last-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const phoneNumber = document.getElementById('phone-number').value;
    fetch('http://localhost:3001/register', {  // Updated port number
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ firstName, lastName, email, password, phoneNumber })
    })
    .then(response => response.ok ? alert('Registration successful') : alert('Registration failed'));
}

function getProperties() {
    const location = document.getElementById('filter-location').value;
    const bedrooms = document.getElementById('filter-bedrooms').value;
    const bathrooms = document.getElementById('filter-bathrooms').value;
    fetch('http://localhost:3001/properties')  // Updated port number
    .then(response => response.json())
    .then(properties => {
        const filteredProperties = properties.filter(property => {
            return (!location || property.location.includes(location)) &&
                   (!bedrooms || property.bedrooms == bedrooms) &&
                   (!bathrooms || property.bathrooms == bathrooms);
        });
        displayProperties(filteredProperties);
    });
}

function displayProperties(properties) {
    const propertiesDiv = document.getElementById('properties');
    propertiesDiv.innerHTML = '';
    properties.forEach(property => {
        const propertyDiv = document.createElement('div');
        propertyDiv.classList.add('property');
        propertyDiv.innerHTML = `
            <h3>${property.location}</h3>
            <p>Area: ${property.area} sq ft</p>
            <p>Bedrooms: ${property.bedrooms}</p>
            <p>Bathrooms: ${property.bathrooms}</p>
            <button onclick="showInterest(${property.id})">I'm Interested</button>
        `;
        propertiesDiv.appendChild(propertyDiv);
    });
}

function showInterest(propertyId) {
    fetch(`http://localhost:3001/interest/${propertyId}`, {  // Updated port number
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => {
        alert(`Contact details of the seller: Email - ${data.email}, Phone - ${data.phoneNumber}`);
    });
}
